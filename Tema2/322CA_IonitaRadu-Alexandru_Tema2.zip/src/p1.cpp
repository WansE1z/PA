#include <bits/stdc++.h>

#include <fstream>
using namespace std;
ifstream fin("p1.in");
ofstream fout("p1.out");
int main() { return 0; }
