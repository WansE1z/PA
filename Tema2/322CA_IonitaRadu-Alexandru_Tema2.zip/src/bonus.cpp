#include <bits/stdc++.h>

#include <fstream>
using namespace std;
ifstream fin("bonus.in");
ofstream fout("bonus.out");
int main() { return 0; }
