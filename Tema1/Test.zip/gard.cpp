#include <algorithm>
#include <fstream>
#include <stack>
#include <vector>

using namespace std;
ifstream fin("gard.in");
ofstream fout("gard.out");
const int NMAX = 1000000;
struct interval {
  int left, right;
  bool operator<(const interval &a) const {
    if (left == a.left) return right > a.right;
    return left < a.left;
  }
};
vector<interval> v;
stack<interval> st;

int main() {
  int n;
  interval aux;
  fin >> n;

  for (int i = 1; i <= n; i++) {
    fin >> aux.left >> aux.right;
    v.push_back(aux);
  }
  sort(v.begin(), v.end());
  st.push(v[0]);
  for (unsigned int i = 1; i < v.size(); i++) {
    aux = st.top();
    if (v[i].right <= aux.right)
      continue;
    else
      st.push(v[i]);
  }
  fout << n - st.size() << "\n";

  return 0;
}
