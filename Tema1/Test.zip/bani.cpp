#include <fstream>

using namespace std;
ifstream fin("bani.in");
ofstream fout("bani.out");
const int NMAX = 10;
const long long MOD = 1000000007;
long long dp[5][NMAX];
/// 1 - 10 lei
/// 2 - 50 lei
/// 3 - 100 lei
/// 4 - 200 lei
/// 5 - 500 lei
long long lg_power(long long base, long long exponent) {
  long long result = 1;
  while (exponent > 0) {
    if (exponent & 1) result = (result * (base % MOD)) % MOD;
    base = ((base % MOD) * (base % MOD)) % MOD;
    exponent = exponent >> 1;
  }
  return result % MOD;
}
int main() {
  long long n, t, i;
  long long sol = 0;
  fin >> t >> n;

  if (t == 1) {
    sol = (5 * lg_power(2, n - 1)) % MOD;
    fout << sol << "\n";
  } else {
    for (i = 1; i <= 5; i++) dp[1][i] = 1;
    for (i = 2; i <= n; i++) {
      dp[i % 2][1] = ((dp[(i - 1) % 2][2] + dp[(i - 1) % 2][3]) % MOD +
                      dp[(i - 1) % 2][5]) %
                     MOD;
      dp[i % 2][2] = (dp[(i - 1) % 2][1] + dp[(i - 1) % 2][4]) % MOD;
      dp[i % 2][3] = ((dp[(i - 1) % 2][1] + dp[(i - 1) % 2][3]) % MOD +
                      dp[(i - 1) % 2][4]) %
                     MOD;
      dp[i % 2][4] = (dp[(i - 1) % 2][2] + dp[(i - 1) % 2][5]) % MOD;
      dp[i % 2][5] = dp[(i - 1) % 2][4];
    }

    for (i = 1; i <= 5; i++) sol = (sol + dp[n % 2][i]) % MOD;
    fout << sol << "\n";
  }
  return 0;
}
