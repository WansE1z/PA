#include <fstream>

using namespace std;
ifstream fin("bomboane.in");
ofstream fout("bomboane.out");
const int NMAX = 2000;
const long long MOD = 1000000007;
long long sums[NMAX + 5];
long long dp[55][NMAX + 5];
int m, n;
void sums_computation(int j) {
  sums[0] = dp[j][0];
  for (int i = 1; i <= m; i++) sums[i] = (sums[i - 1] + dp[j][i]) % MOD;
}

int main() {
  int left, right, i, j;
  fin >> n >> m;
  dp[0][0] = 1;
  for (j = 1; j <= n; j++) {
    fin >> left >> right;
    for (i = m; i >= 0; i--) {
      for (int k = i - left; k >= i - right; k--) {
        if (k < 0) break;
        dp[j][i] = (dp[j - 1][k] + dp[j][i]) % MOD;
      }
      if (i == m && j == n) {
        fout << dp[n][m] << "\n";
        return 0;
      }
    }
  }

  return 0;
}
