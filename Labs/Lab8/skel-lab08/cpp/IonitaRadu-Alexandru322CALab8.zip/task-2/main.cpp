#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int kNmax = 11500;
int a[kNmax][kNmax] = {0};
int m,n;
int copie[kNmax][kNmax] = {0};
ofstream fout("out");

void citire()
{
    int x,y;
    ifstream fin("in");
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        a[x][y]=a[y][x]=1;
    }
}

void elimin_nod(int x)
{
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            if(i==x||j==x)
                copie[i][j]=0;
            else
                copie[i][j]=a[i][j];

}

void elimin_muchie(int x,int y)
{
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            copie[i][j]=a[i][j];
    copie[x][y]=copie[y][x]=0;
}

void BFS(int x,vector<bool>&viz)
{
    queue<int> q;
    viz[x]=1;
    q.push(x);
    while(q.size())
    {
        int nod_crt=q.front();
        q.pop();
        for(int i=1; i<=n; i++)
            if(copie[nod_crt][i]==1 && viz[i]==0)
            {
                q.push(i);
                viz[i]=1;
            }
    }
}

int componente_conexe()
{
    int nr=0;
    vector<bool>viz(n+1,0);
    for(int i=1; i<=n; i++)
        if(viz[i]==0)
        {
            BFS(i,viz);
            nr++;
        }
    return nr;
}

void noduri_critice()
{
    elimin_nod(0);
    int nr_c=componente_conexe();
    for(int i=1; i<=n; i++)
    {
        elimin_nod(i);
        if(componente_conexe()-1!=nr_c)
            fout<<i<<" ";
    }
}

int main()
{
    vector<bool>viz(n+1,0);
    citire();
    elimin_nod(0);
    BFS(1,viz);
    noduri_critice();
}
